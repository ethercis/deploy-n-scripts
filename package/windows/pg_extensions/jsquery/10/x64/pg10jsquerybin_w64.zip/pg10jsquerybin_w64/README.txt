This is for PostgreSQL 64-bit and should work for both EDB and BigSQL Windows 64-bit distributions

For EDB: Copy binaries to respective folders in your PostgreSQL  install.
For BigSQL: copy the lib files into lib/postgresql folder, share/extension files in share/postgresql
  Be careful not to overwrite any files that came with you PostgreSQL distribution
  
In your database run:


CREATE EXTENSION jsquery;

To do a quick test try:

create extension jsquery;

SELECT f.data->>'name' AS name
FROM (VALUES ('{"age": 3, "name": "Elle"}'::jsonb) , 
    ('{"age": 4, "name": "Peger"}'::jsonb) ) AS f(data)
WHERE  f.data @@ '"age" > 3';



jsquery master branch As of 5/20/2017 (b70cf0fe2f24fdf0cfd0b454ce35c435a891cc5a)
https://github.com/postgrespro/jsquery

Compiled using mingw64-w64 GCC 4.9.2 (x86_64-win32-seh-rev4, Built by MinGW-W64 project)


